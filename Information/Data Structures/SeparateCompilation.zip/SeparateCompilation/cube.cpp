// cube.cpp
//
// CS 124-03 Spring 2021
// Week 1 Code Example
// Implementation of the cube function.  

#include "math.h"


int cube(int n)
{
	return n * n * n;
}
