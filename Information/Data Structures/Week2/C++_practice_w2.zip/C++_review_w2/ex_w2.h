#pragma once

/* CS 124-3 
 * C++ Review Examples 
 * Filename: ex_w2.h
 * 2/1/21
 */

// functions we use in ex_w2.cpp

int factorial(int number); // definition before use
void printTenTimes(char c);
int doubleValue(int x);
void doubleValueWithRef(int &x);
int square(int x);
bool even(int value);
