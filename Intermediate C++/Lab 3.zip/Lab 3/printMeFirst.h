#ifndef LAB_PRINTMEFIRST_H
#define LAB_PRINTMEFIRST_H
#include <string>
using namespace std;
void printMeFirst(string name, string courseInfo);
#endif //LAB_PRINTMEFIRST_H
