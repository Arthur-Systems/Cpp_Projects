/*
Purpose- Prints the information of the developer.
@author Haichuan Wei
@version 1.0 9/2/21
@using  CLion
@param name - Haichuan Wei
@param courseInfo - CS-116 OOP C++
@return- none
*/
#ifndef LAB_1_PRINTMEFIRST_H
#define LAB_1_PRINTMEFIRST_H
#include <string>
using namespace std;
void printMeFirst(string name, string courseInfo);
#endif //LAB_1_PRINTMEFIRST_H
